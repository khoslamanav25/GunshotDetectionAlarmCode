import React, { useState, useEffect } from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { createMaterialBottomTabNavigator } from "@react-navigation/material-bottom-tabs";
import DetectionScreen from "./screens/DetectionScreen";
import Tab2 from "./screens/Tab2";
import Tab3 from "./screens/Tab3";
import WelcomeScreen from "./screens/WelcomeScreen"
import {
  Entypo,
  MaterialCommunityIcons,
  FontAwesome5,
} from "@expo/vector-icons";
// import Firebasekeys from "./config";
// import * as firebase from "firebase";
// import "firebase/firestore";

// let firebaseConfig = Firebasekeys;
// if (!firebase.apps.length) {
//   firebase.initializeApp(firebaseConfig);
// }
const inactiveColor = '#8E8E8E'
const themecolor = '#1D00AD'
const tabcolor = '#FF5349'
const Tab = createMaterialBottomTabNavigator();
const Home = createStackNavigator();

const HomeScreenNavigator = ({ navigation }) => {
  return (
    <Home.Navigator
      screenOptions={{
          headerShown:true
        }}
      
      initialRouteName="Home Screen"
    >
      <Home.Screen name="Welcome Screen" component={WelcomeScreen} options={{
        title: 'Welcome',
        headerShown: false,
          headerStyle: {
            backgroundColor: `${themecolor}`
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
            color: '#fff'
          },
          headerBackTitleStyle: {
            color: `${tabcolor}`
          },
          headerTintColor: `${tabcolor}`,
        }}/>
      <Home.Screen name="Detection Screen" component={DetectionScreen} 
      options={{
        title: 'Detection',
        headerShown: false,
          headerStyle: {
            backgroundColor: `${themecolor}`
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: 'bold',
            color: '#fff'
          },
          headerBackTitleStyle: {
            color: `${tabcolor}`
          },
          headerTintColor: `${tabcolor}`,
        }}/>
    </Home.Navigator>
  );
};

function MainTabs() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        initialRouteName="Dashboard"
        sceneAnimationEnabled="true"
        activeColor={tabcolor}
        inactiveColor={inactiveColor}
        barStyle={{ backgroundColor: `${themecolor}`, bottomPadding: 10 }}
        shifting={true}
      >
        <Tab.Screen
          name="Dashboard"
          component={HomeScreenNavigator}
          options={{
            tabBarIcon: ({ focused }) => (
              <MaterialCommunityIcons
                name="view-dashboard"
                size={26}
                color={focused ? tabcolor : inactiveColor}
              />
            ),
          }}
        />
        <Tab.Screen
          name="News Feed"
          component={Tab3}
          options={{
            tabBarIcon: ({ focused }) => (
              <FontAwesome5
                name="newspaper"
                size={23}
                color={focused ? tabcolor : inactiveColor}
              />
            ),
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
export default function App2() {

  return <MainTabs/>

}